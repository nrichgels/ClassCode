#ifndef __PROTOTYPES_H__
#define __PROTOTYPES_H__
BST<Student> ReadInput(ifstream& in);
void WriteOutput(ofstream& out, BST<Student> Tree);
#endif
