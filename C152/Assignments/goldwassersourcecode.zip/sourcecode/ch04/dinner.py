# Program: dinner.py
# Authors: Michael H. Goldwasser
#          David Letscher
#
# This example is discussed in Chapter 4 of the book
# Object-Oriented Programming in Python
#
dinner = raw_input('What would you like for dinner? ')
if dinner == 'pizza':
  print 'Great!'
  print 'I love pepperoni and black olives.'
else
  print 'How about pizza?'
