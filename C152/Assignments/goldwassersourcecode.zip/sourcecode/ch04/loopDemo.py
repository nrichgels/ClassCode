# Program: loopDemo.py
# Authors: Michael H. Goldwasser
#          David Letscher
#
# This example is discussed in Chapter 4 of the book
# Object-Oriented Programming in Python
#
guests = ['Carol', 'Alice', 'Bob']
for person in guests:
  print 'Hello my name is', person
