# Program: blastoff.py
# Authors: Michael H. Goldwasser
#          David Letscher
#
# This example is discussed in Chapter 4 of the book
# Object-Oriented Programming in Python
#
for count in range(10, 0, -1):
  print count
print 'Blastoff!'
